#include "Face_Crystal.h"
#include "Mesh.h"
#include <GL/glut.h>

extern bool g_isMixedFace;
extern float g_mixedR, g_mixedG, g_mixedB;

// CrystalFace.dat
static Mesh g_crystalFaceMesh("assets/SOR/CrystalFace.dat");

void FaceCrystal::draw()
{
    // �⺻ ��
    if (g_isMixedFace)
        glColor3f(g_mixedR, g_mixedG, g_mixedB);
    else
        glColor3f(0.0f, 0.0f, 1.0f);

    // �Ʒ��� cone (��)
    glPushMatrix();
    glRotatef(90, 1, 0, 0);
    glutSolidCone(0.5, 0.8, 20, 20);
    glPopMatrix();

    // ���� cone (������)
    glPushMatrix();
    glRotatef(-90, 1, 0, 0);
    glTranslatef(0.0f, 0.0f, 1.0f);
    glutSolidCone(0.5, 0.8, 20, 20);
    glPopMatrix();

    // Mini cone (��)
    glPushMatrix();
    glScalef(0.3f, 0.3f, 0.3f);
    glRotatef(90, 1, 0, 0);
    glTranslatef(0.0f, 0.0f, -1.0f);
    glutSolidCone(0.5, 0.8, 20, 20);
    glPopMatrix();

    // Mini cone (������)
    glPushMatrix();
    glScalef(0.3f, 0.3f, 0.3f);
    glRotatef(-90, 1, 0, 0);
    glTranslatef(0.0f, 0.0f, 1.0f);
    glutSolidCone(0.5, 0.8, 20, 20);
    glPopMatrix();

    // ��� ��Ȧ��/�� (SOR ��)
    glPushMatrix();
    if (!g_isMixedFace)
        glColor3f(0.8f, 0.9f, 1.0f);

    glTranslatef(0.0f, 0.5f, 0.0f);  // �� cone ����
    glScalef(0.6f, 0.6f, 0.6f);
    g_crystalFaceMesh.draw();
    glPopMatrix();
}
